# Capture Examples — the standard, worked

Six real-shaped captures. Study the pattern, not the words: the user interrupts,
the capture lands whole, the user is handed back their thread. Every one runs in
under five seconds of the user's attention. None of them asks a question.

---

## 1 · Mid-build feature idea → ATTACHED

The user is deep in a build session, wiring a webhook that syncs form fills into
their CRM.

**The user, mid-thought:**

> wait — squirrel that: the webhook should also fire a Slack ping when the lead
> score is over 80, sales keeps missing the hot ones

This is directly additive to the exact task on the table — same build, same webhook,
attaching it accelerates the work. Attach, don't box.

**The capture:**

```
🐿️ SQUIRREL CAPTURED — ATTACHED
"Slack ping on lead score >80" → attached to: the webhook sync build (this session)
Reason: same webhook, same payload — it's a branch on the pipeline we're already wiring.

Now — back to the form-fill sync. Where were we?
```

**Why it went this way:** clear, obvious parent. Not a loose thematic connection —
the squirrel literally lives inside the thing being built. The note lands on the
task (or in the session plan), not in the box.

---

## 2 · Business idea → IN THE BOX

The user is debugging a client's email automation. The idea has nothing to do with
the debugging.

**The user, mid-thought:**

> idea — a CRM built only for home inspectors. every one of them re-types the
> report data twice. squirrel it

**The capture:**

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"CRM built only for home inspectors"
Type: 🏢 Business | Energy: Hot | Potential: 🚀 High
Chase Month: 2026-09
→ saved to squirrel-box.md

Now — back to the email automation. Where were we?
```

**What got written to the box:**

```markdown
### CRM built only for home inspectors
- Captured: 2026-08-14
- Type: 🏢 Business
- Energy: Hot
- Status: Raw
- Potential: 🚀 High
- Effort to Validate: quick
- Domain: Product
- Context: Mid-debug on the Hendersons' email automation. User: "a CRM built only for home inspectors. every one of them re-types the report data twice." Third time this month the user has mentioned inspectors re-keying data — the pain is observed, not imagined.
- Next Action: Ask two inspector contacts what tool they use today and what they pay. Two calls, one afternoon.
- Attached To: —
- Source: Henderson email automation debug session
- Chase Month: 2026-09
```

**Why it went this way:** new entity, new direction — never attach a new business to
a client bugfix. Energy read Hot from "every one of them" — the user has receipts.
Next Action is the cheapest possible test, not a business plan.

---

## 3 · Strategy → IN THE BOX

The user is writing a proposal and pauses on the pricing section.

**The user, mid-thought:**

> bottle that — what if every proposal led with a fixed-price diagnostic instead
> of hourly discovery. anchor small, expand from evidence

**The capture:**

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"Fixed-price diagnostic as the front door"
Type: 🗺️ Strategy | Energy: Warm | Potential: 📈 Medium
Chase Month: 2026-09
→ saved to squirrel-box.md

Now — back to the proposal. Where were we?
```

**What got written to the box:**

```markdown
### Fixed-price diagnostic as the front door
- Captured: 2026-08-14
- Type: 🗺️ Strategy
- Energy: Warm
- Status: Raw
- Potential: 📈 Medium
- Effort to Validate: quick
- Domain: Strategy
- Context: Writing the Meridian proposal, stalled on hourly pricing. User: "what if every proposal led with a fixed-price diagnostic instead of hourly discovery. anchor small, expand from evidence." Note: current proposal could pilot this without any repositioning.
- Next Action: Price the diagnostic in the Meridian proposal as a test. One data point, zero downside.
- Attached To: —
- Source: Meridian proposal drafting session
- Chase Month: 2026-09
```

**Why it went this way:** tempting to attach to the open proposal — but this is a
positioning move that outlives one document, so it's boxed, and the live proposal
becomes its Next Action. That's the pattern: box the strategy, borrow the moment.

---

## 4 · Person/Partner → IN THE BOX

The user is reviewing a podcast transcript for content clips.

**The user, mid-thought:**

> don't let me forget — the guest at minute 40, Priya, runs ops for 60 restaurants
> and hates her vendor stack. I should know her

**The capture:**

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"Priya — ops lead across 60 restaurants, vendor-stack pain"
Type: 👤 Person/Partner | Energy: Warm | Potential: 🔍 Unknown
Chase Month: 2026-09
→ saved to squirrel-box.md

Now — back to the transcript. Where were we?
```

**What got written to the box:**

```markdown
### Priya — ops lead across 60 restaurants, vendor-stack pain
- Captured: 2026-08-14
- Type: 👤 Person/Partner
- Energy: Warm
- Status: Raw
- Potential: 🔍 Unknown
- Effort to Validate: quick
- Domain: Network
- Context: Reviewing podcast ep. 14 transcript for clips. Guest at ~minute 40: Priya, runs operations for a 60-location restaurant group, spoke at length about hating her vendor stack. User: "I should know her." A warm path likely exists through the podcast host.
- Next Action: One intro request to the host. If Priya says yes, a 20-minute call.
- Attached To: —
- Source: Podcast ep. 14 transcript review
- Chase Month: 2026-09
```

**Why it went this way:** people are squirrels too — some of the best ones. Potential
is honestly 🔍 Unknown; the capture preserves the who, the where, and the warm path
before all three evaporate.

---

## 5 · Direction → IN THE BOX

The user is doing month-end invoicing and goes quiet, then:

**The user, mid-thought:**

> capture that — I think the whole agency model is wrong for me. productized
> tools, not retainers. not this year maybe. but that's the direction

**The capture:**

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"Productized tools over retainers — the long-horizon shift"
Type: 🧠 Direction | Energy: Cool | Potential: 🚀 High
Chase Month: 2026-09
→ saved to squirrel-box.md

Now — back to the invoicing. Where were we?
```

**What got written to the box:**

```markdown
### Productized tools over retainers — the long-horizon shift
- Captured: 2026-08-14
- Type: 🧠 Direction
- Energy: Cool
- Status: Raw
- Potential: 🚀 High
- Effort to Validate: heavy
- Domain: Strategy
- Context: Month-end invoicing. User, unprompted: "I think the whole agency model is wrong for me. productized tools, not retainers. not this year maybe. but that's the direction." Said calmly, not in frustration — reads as thesis, not venting.
- Next Action: Tag the next three squirrels that fit this direction when they arrive. A thesis is validated by what keeps pointing at it.
- Attached To: —
- Source: Month-end invoicing session
- Chase Month: 2026-09
```

**Why it went this way:** Cool energy and heavy validation are not marks against it —
a Direction squirrel is a compass, not a task. Note the Next Action: directions
aren't validated by a phone call, they're validated by accumulation.

---

## 6 · The half-sentence fragment → IN THE BOX

The user is mid-code-review. This is the whole message:

**The user, mid-thought:**

> squirrel: audit logs as a product??

**The capture:**

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"Audit logs as a standalone product"
Type: 💡 Idea | Energy: Hot | Potential: 🔍 Unknown
Chase Month: 2026-09
→ saved to squirrel-box.md

Now — back to the code review. Where were we?
```

**What got written to the box:**

```markdown
### Audit logs as a standalone product
- Captured: 2026-08-14
- Type: 💡 Idea
- Energy: Hot
- Status: Raw
- Potential: 🔍 Unknown
- Effort to Validate: medium
- Domain: Product
- Context: Mid-code-review on the client portal PR — we had just walked through the portal's audit-trail middleware when the user fired "audit logs as a product??" Fragment only; the double question mark and timing suggest the middleware looked more valuable than the portal around it.
- Next Action: Sketch what the middleware would need to stand alone (auth, ingest, retention). One page, then judge.
- Attached To: —
- Source: Client portal PR review
- Chase Month: 2026-09
```

**Why it went this way:** four words was enough. The capture supplied everything else
from context — that is the job. No follow-up question, no "can you say more?" The
Context field records the surrounding work precisely so future-user can reconstruct
what present-user meant.

---

## The pattern, compressed

1. The user never repeats themselves and is never questioned.
2. The name is specific enough to be recognized cold, months later.
3. Context carries the scene, not just the sentence — more is more.
4. Next Action is the cheapest step that could validate or kill.
5. Every capture ends the same way: **"Now — back to [X]. Where were we?"**
