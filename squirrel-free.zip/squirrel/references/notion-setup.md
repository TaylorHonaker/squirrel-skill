# Notion Setup — the preferred box

The plain file needs zero setup and never fails. But the original Squirrel Box was
born in Notion, and Notion is still the best home it has: a real database you can
query, sort, filter, and link from anywhere. Every squirrel becomes a page. Every
Chase becomes a saved view away. It survives everything — new machine, new platform,
new AI. Five minutes of setup, paid back every month.

No IDs to configure, nothing to install in this skill. You build the database,
connect your AI to Notion, and say where the box lives. Done.

---

## STEP 1 — CREATE THE DATABASE

In Notion, create a new database (full page is best). Name it exactly:

**Squirrel Box 🐿️**

---

## STEP 2 — ADD THE 13 PROPERTIES

The box is 13 properties. Add them with these exact names and types:

| # | Property | Notion type | Options |
|---|----------|-------------|---------|
| 1 | Squirrel | Title | — (the idea's name; every database starts with a Title) |
| 2 | Type | Select | 💡 Idea · 🏢 Business · ⚙️ Feature · 🗺️ Strategy · 🔬 IP/Invention · 📦 Repo/Tool · 🧠 Direction · 👤 Person/Partner · 📋 Resource · 🌀 Other |
| 3 | Energy | Select | Hot · Warm · Cool |
| 4 | Status | Select | Raw · Assessed · Attached · In Queue · Chased · Archived |
| 5 | Potential | Select | 🚀 High · 📈 Medium · 🔍 Unknown · ❌ Low |
| 6 | Effort to Validate | Select | quick · medium · heavy |
| 7 | Domain | Multi-select | Client Work · Product · Infrastructure · Strategy · IP · Revenue Partners · Personal |
| 8 | Context | Text | — |
| 9 | Next Action | Text | — |
| 10 | Attached To | Text (or a Relation to your task database, if you have one) | — |
| 11 | Source Chat | URL | — |
| 12 | Captured | Date | — |
| 13 | Chase Month | Date | — |

Two notes:

- The Domain options above are a starting set. Rename them to your own areas of
  work and life — the skill uses whatever options exist.
- Selects grow as needed. If the skill ever writes a status or type the select
  doesn't have yet, Notion adds the option automatically. Nothing breaks.

---

## STEP 3 — CONNECT YOUR AI TO NOTION

The skill can only write where your AI can reach.

- **claude.ai:** Settings → Connectors → Notion. Authorize, and grant access to
  the page or workspace holding the box.
- **Claude Desktop / Claude Code:** add the Notion MCP server, then grant it
  access to the box's page.
- **Any other platform:** use that platform's Notion integration or connector —
  whatever lets its AI read and write your Notion pages. Same result.

---

## STEP 4 — TELL THE SKILL ONCE

Open the database in Notion, copy its link, and say:

> my squirrel box lives in Notion: [paste database link]

That's it. The skill captures there from now on — stated once, remembered forever.

---

## MIGRATING A PLAIN-FILE BOX

Already have squirrels in `squirrel-box.md`? Paste the file into the chat (or point
the skill at it) and ask it to move the entries in. The 13 fields map one to one —
one label shifts in the move: the plain file's `Source` maps to Notion's
`Source Chat` (the plain file's sources aren't always chats; Notion's URL property
is) — nothing is lost. Keep the old file as a souvenir or delete it — the box has
moved.

---

## NOT NOTION?

The same shape works anywhere that holds text. Airtable, Google Sheets, Obsidian,
ClickUp — build the 13 properties (or columns, or fields) above, connect your AI to
it, and tell the skill where the box lives. The protocol doesn't care about the
container. It cares that the lightning lands.
