# Squirrel Skill 🐿️ — free edition

**Squirrel Skill 1.3.0 (free)** · Squirrel Box Format v1

Say **"squirrel that"** mid-sentence and the idea gets bottled in a structured
13-field record — about five seconds — and you get handed straight back to whatever
you were doing.

Free forever. No account, no email, no server. Nothing here phones home; there is
nothing to phone.

---

## Install — about a minute

**claude.ai or Claude Desktop**
Settings → Capabilities → Skills → upload the ZIP → toggle it on.

**Claude Code**

```bash
unzip squirrel-free.zip -d ~/.claude/skills/
```

**Anywhere else that runs Agent Skills**
Point it at the unzipped `squirrel/` folder.

**No skills support at all?** Paste `SKILL.md` into any capable AI as its
instructions. The protocol runs the same.

---

## Your first capture

Don't set anything up. Next time an idea hits you mid-task, just say it:

> wait — squirrel that: template packs for the trades, $49 each, plumbers first

The skill writes the capture, tells you where it landed, and hands your thread back.
On the very first capture it creates the box for you. **You are never asked a
question mid-capture** — that is the whole design.

Other phrases that work: *capture that · bottle that · don't let me forget · park
that · idea — · squirrel it*

---

## Where your box lives

| Lane | Setup |
|---|---|
| **Plain file** (default) | none — a markdown file you own |
| **Notion** (preferred) | 5 minutes — `references/notion-setup.md` |
| **Anything that holds text** | map the 13 fields |

Say it once — *"my squirrel box lives in Notion: [link]"* — and it is remembered
from then on.

---

## What's in this folder

| File | What it's for |
|---|---|
| `SKILL.md` | the protocol itself — this is the skill |
| `references/capture-examples.md` | six worked captures, with the reasoning shown |
| `references/notion-setup.md` | the preferred box, in 5 minutes |

---

## What this edition does and doesn't do

**It captures.** Every idea, structured the same way, in about five seconds, with
your momentum handed back. That half is free forever and it is complete — nothing
here is a trial or a teaser.

**It doesn't judge.** The Full Squirrel Box adds the monthly Chase: every idea
competes, five carry forward and earn a nut, six nuts is a green light, and twelve
chases crown your idea of the year. That is the part that turns a pile of captures
into a decision.

Captures made here transfer straight across — same 13 fields, same box. Nothing you
record now is wasted if you upgrade later.

<https://www.squirrelskill.com>

---

AI Company USA dba SUMMIT Business Automation · Helena, Montana
