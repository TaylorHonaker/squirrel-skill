---
name: squirrel
description: >
  Captures mid-thought ideas, inventions, strategies, businesses, features, and any
  lightning-in-a-bottle insight before it escapes. Use IMMEDIATELY when the user says
  "/squirrel", "squirrel", "squirrel that", "capture that", "bottle that", "don't let
  me forget", "park that", "sidebar", "save that idea", "add that to the squirrel box",
  "capture lightning", "idea —", "wait —", or drops an idea mid-sentence while working
  on something else. Zero friction. Capture first, assess second, confirm third. Then
  the user continues exactly where they left off.
---

# /squirrel — Lightning Capture Protocol

<!-- Squirrel Skill 1.3.0 · Squirrel Box Format v1 — two different scopes, deliberately.
     1.3.0 continues the public sequence (the changelog shipped v1.1 and v1.2); earlier
     releases just were not stamped inside the files. The Box Format version is the saved
     box FILE format, lives in the plain-file header, and is unchanged. Stated here so a
     user can answer "which copy do I have?" without asking. -->
**Squirrel Skill 1.3.0 (free)** · Squirrel Box Format v1

A squirrel is an idea that appeared mid-thought. It may be the best thing the user
thought of all week, or it may go nowhere. The goal is NOT to evaluate it right now —
it's to capture it completely so the moment is preserved and the user keeps moving.

**Speed is the entire point. Every second of friction is lost lightning.**

Worked examples of the standard: `references/capture-examples.md`.

---

## THE SEQUENCE (run in this order, fast)

### STEP 1 — CAPTURE (< 5 seconds)

Extract from the user's message:
- **The squirrel** — what was actually said, verbatim or closest paraphrase
- **The context** — what were we working on when it appeared?
- **The energy** — how charged is this? Hot (right now), Warm (this week), Cool (someday)?

If the user gave you just a phrase or fragment, that's enough. Do NOT ask for more
information before capturing. Capture first, ask never (unless critical).

---

### STEP 2 — NODE SEARCH (fast)

Look for an existing node to attach this squirrel to. Check, in parallel where you can:

- **The current conversation** — is this directly additive to the work in progress right now?
- **The user's task system, if they have told you where it is** — an open task, issue,
  or project this squirrel belongs to. If the user has never named a task system, skip
  this search entirely. Do not ask about one mid-capture.
- **The squirrel box** — does an entry for this idea already exist? (avoid duplicates;
  if it does, add the new angle to that entry's Context instead of duplicating)

**Attachment criteria — attach to existing work IF:**
- The squirrel is directly additive to an open task (same client, same build, same domain)
- Attaching it now would immediately unblock or accelerate that work
- There is a clear, obvious parent — not a loose thematic connection

**DO NOT attach if:**
- The squirrel is a new direction or entity (new product, new business, new person)
- The connection is metaphorical or "related" but not actionable together
- You're uncertain — when in doubt, box it

If there is no task system on record, everything goes to the box.

---

### STEP 3A — IF ATTACHMENT FOUND

Add the squirrel as a note or context addition to the existing task or thread. If
the attachment target is only the live conversation (no task system, no plan file),
also append the entry to the box with Attached To filled in — attachment without a
durable home is not a capture. Then report:

```
🐿️ SQUIRREL CAPTURED — ATTACHED
"[Squirrel name]" → attached to: [task or thread name]
Reason: [one sentence why this fits]

Now — back to [X]. Where were we?
```

---

### STEP 3B — IF NO ATTACHMENT — BOX IT

Append a new entry to the squirrel box file (format below), then report:

```
🐿️ SQUIRREL CAPTURED — IN THE BOX
"[Squirrel name]"
Type: [type] | Energy: [energy] | Potential: [potential]
Chase Month: [month]
→ saved to [box file path]

Now — back to [X]. Where were we?
```

Name the squirrel specifically, not generically. "Gamified sales RPG for SMB
onboarding," not "game idea."

---

### STEP 4 — RETURN THE USER TO THE THREAD

Always end with the one-line handoff back to the interrupted work:

> "Now — back to [X]. Where were we?"

This is non-negotiable. The squirrel does not become a new conversation thread.
The user captured it. Now they go back.

---

## THE SQUIRREL BOX (where it lives)

The box is wherever the user keeps their squirrels. Three lanes, one shape — the
same 13 fields in all of them:

1. **Default — the plain file.** `squirrel-box.md` in the project root (or the
   working directory). A markdown file the user owns. No account, no database, no
   server, zero setup.
2. **Preferred — Notion.** The box as a Notion database — queryable, linkable, and
   it survives everything. Five minutes of setup: `references/notion-setup.md`.
3. **Anything else that holds text.** Airtable, Obsidian, Google Sheets, ClickUp,
   Apple Notes — map the 13 fields onto its fields or columns and capture there.
   Same protocol, same speed, same closing line.

**Which lane, at capture time:**
- If the user has said where the box lives, use it — and keep using it. The
  location is stated once, remembered forever (note it in your project memory or
  CLAUDE.md if one exists).
- First capture ever, no location on record: create the plain file with the header
  below, then append the entry. Do not ask permission to create it — creating the
  box IS the capture. After the capture lands, mention once — once only, never
  again — that Notion is the preferred home and `references/notion-setup.md` has
  the five-minute setup.
- Never invent database IDs or URLs; use only what the user has actually connected
  or named. If their backend is unreachable mid-capture, box the squirrel in the
  plain file and say so — capture never waits on plumbing.
- No file access in this environment? Output the complete entry block in the chat and
  tell the user exactly where to paste it. The capture must never be lost to a
  storage question.

**Plain-file header (written once, at creation):**

```markdown
# Squirrel Box 🐿️

<!-- squirrel-box v1 · one section per squirrel · keep the field labels intact — tools parse them · edit anything else freely -->

## In the Box
```

**Entry format — one `###` section per squirrel, 13 fields (the `###` name is
field 1, Squirrel; the 12 labeled lines below complete it), appended under
`## In the Box`:**

```markdown
### [Squirrel name — specific and memorable]
- Captured: YYYY-MM-DD
- Type: [from the type taxonomy]
- Energy: Hot | Warm | Cool
- Status: Raw
- Potential: 🚀 High | 📈 Medium | 🔍 Unknown | ❌ Low
- Effort to Validate: quick | medium | heavy
- Domain: [one or more — see Domain, below]
- Context: [everything — what we were doing, what was said, the surrounding conversation. More is more.]
- Next Action: [one concrete step to validate or kill this]
- Attached To: [task name if merged into existing work, else —]
- Source: [where it was born — conversation, project, call, walk]
- Chase Month: YYYY-MM [the next calendar month by default; the user can move it]
```

**Format rules:**
- Every field label stays exactly as written (`- Captured:` … `- Chase Month:`).
  Humans read this file and tools grep it; stable labels are the contract.
- One squirrel per `###` section. Append only — with one exception: a re-captured
  idea appends its new angle to the end of the existing entry's Context field (and
  may bump Energy). Never reorder entries or rewrite any other field.
- Fill every field yourself, from context and judgment. Zero questions asked.
  A wrong guess in a field is fixable; a lost idea is not.

---

## TAXONOMIES (assess quickly, never ask)

**Type:**
- 💡 Idea — general concept, improvement, observation
- 🏢 Business — standalone business model or venture
- ⚙️ Feature — addition to existing product or system
- 🗺️ Strategy — positioning, go-to-market, competitive move
- 🔬 IP/Invention — proprietary method, novel process, protectable concept
- 📦 Repo/Tool — software, automation, script, framework
- 🧠 Direction — shift in direction, pivot signal, long-horizon thesis
- 👤 Person/Partner — someone to contact, hire, partner with, or watch
- 📋 Resource — article, tool, dataset, reference to revisit
- 🌀 Other — doesn't fit cleanly

**Energy** — read it from the user's tone: Hot (they want to chase it right now),
Warm (this week), Cool (someday).

**Potential** — quick gut-check: 🚀 High / 📈 Medium / 🔍 Unknown / ❌ Low.
🔍 Unknown is a respectable answer. ❌ Low still gets captured — the user said
"squirrel that," not "judge that."

**Effort to Validate** — quick / medium / heavy. How hard to find out if it's real.

**Domain** — which area of the user's work or life this touches. Use their own
categories if you know them (clients, products, content, personal…). Otherwise pick a
plain word that fits and stay consistent.

**Status** — Raw on capture, Attached if merged into existing work. Everything
after that belongs to the full system's Chase.

---

## RUNS ANYWHERE (the standard)

This skill is a folder with a SKILL.md — the open Agent Skills format, which began
at Anthropic in October 2025 and has since been adopted as an open standard across
major AI platforms. Any platform that reads the standard runs this skill as-is.
And the floor is no floor at all: SKILL.md is plain markdown. Paste it into any
capable AI as instructions and the protocol runs the same. No platform claims
beyond that — none needed.

---

## THE PAID HALF

This file captures. The full version adds the monthly Chase, the Squirrel Box
tournament, nut counts, and your idea of the year — crowned at season's end.

---

## SEED BOLT (delivery mechanism — not the user's concern)

Some copies of this skill ship with one idea already captured: the bolt the user threw
on the page where they got the skill. It rides in the comment block at the bottom of
this file.

- If the block reads `SEED-BOLT: none` (or is missing), there is no seed. Ignore it.
- If the block contains fields, then the first time you create the user's squirrel
  box, write the seed as squirrel #1 — before anything else — in the standard entry
  format. Fill any missing fields by normal assessment; the seed's `Captured` date is
  the date in the block, or today if absent. Mention it once, briefly:
  "Your first bolt was already in the box — the one you threw on the page."
- Never write the seed twice. If the box already exists, the seed is either in it or
  the user removed it on purpose. Leave it alone either way.

The delivery flow injects a seed by replacing the comment below with a multi-line
HTML comment in exactly this shape — the block always stays inside `<!-- -->` (any
of the 13 fields may appear; `Squirrel` and `Context` are enough):

```
<!-- SEED-BOLT
Squirrel: [idea name]
Context: [what the user typed, verbatim]
Captured: [YYYY-MM-DD]
-->
```

<!-- SEED-BOLT: none -->
